package com.demo;

//import java.util.Scanner;
//
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainMethod {

//	public static void main(String[] args) {
//		
//		ApplicationContext context =   
//			   new ClassPathXmlApplicationContext("Beans.xml");
//		
//		CarInventoryDao dao = context.getBean("cado", CarInventoryDao.class);
//			   // CarInventoryDao dao  = new CarInventoryDao();
//		CarDetailModel carModel = new CarDetailModel();
//		
//		Scanner input = new Scanner(System.in);
//		String makerName = input.nextLine();
//		System.out.print("Enter the Car Maker:");
//		carModel.setMake(makerName);
//		
//		
//		String modelName = input.nextLine();
//		System.out.print("Enter the Car Model:");
//		carModel.setModel(modelName);
//		
//		int carYear = input.nextInt();
//		System.out.print("Enter the Car Year:");
//		carModel.setYear(carYear);
//		
//		float carPrice = input.nextFloat();
//		System.out.print("Enter the Car Year:");
//		carModel.setPrice(carPrice);
//		
//		dao.CreatCarInventory(carModel);
		
		
		
		
		
		
		

//	}

}
