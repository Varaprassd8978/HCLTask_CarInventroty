package com.demo;

public class CarModel {

	public int id;
	public String make;
	public String model;
	public int year;
	public float price;

}
