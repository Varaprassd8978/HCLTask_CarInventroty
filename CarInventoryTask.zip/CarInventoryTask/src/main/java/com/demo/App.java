package com.demo;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {

		try {

			ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

			CarInventoryDao dao = context.getBean("cdao", CarInventoryDao.class);

			CarDetailModel carModel = new CarDetailModel();

			Scanner scanner = new Scanner(System.in);

			System.out.println("1.Add");
			System.out.println("2.list");
			System.out.println("3.quit");

			System.out.println("Enter Command to do the required operations :");
			String commandCode = scanner.nextLine();

			while (commandCode != "3") {

				switch (commandCode) {

				case "1":
					System.out.println("Enter the Car Maker:");
					String makerName = scanner.nextLine();

					System.out.println("Enter the Car Model:");
					String modelName = scanner.nextLine();

					/*
					 * System.out.println("Enter the Car Id:"); int id = scanner.nextInt();
					 */

					System.out.println("Enter the Car Year:");
					int carYear = scanner.nextInt();

					System.out.println("Enter the Car Price:");
					float carPrice = scanner.nextFloat();

					carModel.setMake(makerName);
					carModel.setModel(modelName);
					// carModel.setId(id);
					carModel.setYear(carYear);
					carModel.setPrice(carPrice);

					dao.CreatCarInventory(carModel);

					System.out.println("1.Add");
					System.out.println("2.list");
					System.out.println("3.quit");

					System.out.println("Enter Command to do the required operations :");
					commandCode = scanner.nextLine();

					break;

				case "2":
					List<CarDetailModel> carDetailsList = dao.GetCarDetails();

					carDetailsList.forEach(data -> System.out.println(data.getId() + " " + data.getMake() + " "
							+ data.getModel() + " " + data.getYear() + " " + data.getPrice()));

					// carDetailsList.stream().forEach(System.out::println);
					commandCode = scanner.nextLine();

					break;
				case "3":
					System.out.println("Good Bye...Thank you.....");
					System.out.println("Please visit again........");

					System.out.println("1.Add");
					System.out.println("2.list");
					System.out.println("3.quit");
					System.out.println("Enter Command to do the required operations :");
					commandCode = scanner.nextLine();
					break;

				default:
					System.out.println("You have not entered right command code (1.add, 2.list, 3.quit)!");
					System.out.println("1.Add");
					System.out.println("2.list");
					System.out.println("3.quit");
					System.out.println("Enter Command to do the required operations :");
					commandCode = scanner.nextLine();
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
