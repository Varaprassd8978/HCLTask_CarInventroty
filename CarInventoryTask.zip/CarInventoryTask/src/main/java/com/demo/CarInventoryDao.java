package com.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public class CarInventoryDao {

	// private DataSource dataSource;
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void CreatCarInventory(CarDetailModel model) {

		String insertQuery = "insert into carinventory values(" + model.getId() + ",'" + model.getMake() + "','"
				+ model.getModel() + "'," + model.getYear() + "," + model.getPrice() + ")";
		jdbcTemplate.update(insertQuery);

		System.out.println("Data inserted Successfully");

	}

	public List<CarDetailModel> GetCarDetails() {

		String fetchQuery = "select * from carinventory";

		List<CarDetailModel> CarDetailsList = jdbcTemplate.query(fetchQuery, new RowMapper<CarDetailModel>() {
			public CarDetailModel mapRow(ResultSet result, int row) throws SQLException {
				CarDetailModel carObj = new CarDetailModel();
				carObj.setId(result.getInt("id"));
				carObj.setMake(result.getString("make"));
				carObj.setModel(result.getString("model"));
				carObj.setYear(result.getInt("year"));
				carObj.setPrice(result.getFloat("saleprice"));

				return carObj;
			}
		});

		return CarDetailsList;

	}

}
